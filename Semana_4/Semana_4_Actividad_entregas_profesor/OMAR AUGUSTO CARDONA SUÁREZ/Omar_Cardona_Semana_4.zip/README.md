# Sistema de OnBoarding para Terceros Proveedores de Pago (TPP)
## Modelado UML con Integración del Aseguramiento de la Calidad

**Proyecto Académico**

Especialización en Desarrollo de Software

Autor: **Omar Cardona**

Fecha: **Julio 2026**

---

# Descripción

Este repositorio contiene el modelado UML elaborado para el proyecto de especificación de requisitos del **Sistema de OnBoarding para Terceros Proveedores de Pago (TPP)** de EMC Bank.

El objetivo del modelo es representar la solución de software desde la perspectiva de la Ingeniería de Requisitos y del Aseguramiento de la Calidad, manteniendo trazabilidad entre los requisitos, los casos de uso, los criterios de aceptación y los casos de prueba.

Los diagramas fueron elaborados utilizando **PlantUML**, permitiendo su edición, versionamiento y generación automática de imágenes.

---

# Diagramas incluidos

## 01-Diagrama-Casos-Uso-TPP.puml

Representa la interacción de los diferentes actores con el sistema.

Actores principales:

- Representante del TPP
- Analista de OnBoarding
- Oficial de Cumplimiento
- Administrador del Sistema
- Servicio IA
- Sistema SARLAFT

Casos de uso principales:

- Registrar solicitud
- Cargar documentos
- Validar información
- Ejecutar IA documental
- Consultar SARLAFT
- Aprobar solicitud
- Rechazar solicitud
- Consultar estado
- Administrar parámetros
- Auditoría

---

## 02-Diagrama-Clases-Conceptual-TPP.puml

Modelo conceptual del dominio.

Entidades principales:

- TPP
- SolicitudAfiliacion
- Documento
- ValidacionDocumental
- ValidacionRegulatoria
- Observacion
- Aprobacion
- Usuario
- Rol
- Notificacion
- Auditoria
- ParametroSistema

El modelo representa las relaciones del dominio sin incluir detalles propios del diseño físico.

---

## 03_Trazabilidad_Requisitos_CasosPrueba.puml

Modelo de trazabilidad.

Relaciona:

- Requisitos funcionales
- Casos de uso
- Casos de prueba
- Criterios de aceptación

Permite verificar que cada requisito pueda validarse mediante uno o varios casos de prueba.

---

## 04_Aseguramiento_Calidad_TPP.puml

Modelo del proceso de aseguramiento de la calidad.

Representa:

- Requisitos
- Revisión
- Validación
- Casos de prueba
- Ejecución
- Defectos
- Correcciones
- Liberación

Incluye los principales puntos de control definidos durante el ciclo de vida del software.

---

# Relación con el trabajo final

Los diagramas fueron construidos utilizando como base los pasos desarrollados durante el proyecto:

1. Contexto del sistema
2. Stakeholders
3. Matriz Usuario–Escenario
4. Entrevistas
5. Actas de validación
6. Caracterización de escenarios
7. Catálogo de requisitos funcionales
8. Especificación IEEE 830
9. Criterios de calidad (ISO/IEC 25010 e IEEE 830)

Los modelos UML representan la **solución de software** obtenida a partir de dichos artefactos y no el proceso metodológico utilizado para producirlos.

---

# Herramientas utilizadas

- PlantUML como lenguaje de diagramación
- Visualizador OnLine de Diagramas: https://www.planttext.com/